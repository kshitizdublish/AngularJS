'use strict';

angular.module('myApp.home', [])
    .controller('homeCtrl', function($scope) {
        $scope.myName = 'Kshitiz';
    });