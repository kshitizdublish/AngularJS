'use strict';

angular.module('myApp.contactUs', [])
    .controller('contactUsCtrl', function($scope) {
        $scope.contactNumber = '08496844311';
    });